rem HCT test file - does nothing
