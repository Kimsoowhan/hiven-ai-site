﻿# 시험 전용 묶음의 목록 해시(정답표 2-1의 규칙과 같음): 상대경로(/ 구분) UTF-8 바이트 순 · 「상대경로<탭>크기<탭>SHA256」 · 줄바꿈 LF · 머리줄 1줄 · 끝 줄바꿈 있음 · BOM 없음
# 시작 직후 이 값이 5c6d1c33…4a34와 같아야 한다. 읽기만 하고 결과 파일 한 개만 쓴다.
param(
  [Parameter(Mandatory=$true)][string]$Root,
  [Parameter(Mandatory=$true)][string]$Out,
  [string[]]$ExcludePrefix = @()
)
$ErrorActionPreference = 'Stop'
function Hash-File([string]$path) {
  $sha = [System.Security.Cryptography.SHA256]::Create()
  $fs = [System.IO.File]::Open($path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete)
  try { return ([BitConverter]::ToString($sha.ComputeHash($fs)) -replace '-', '').ToLowerInvariant() } finally { $fs.Dispose(); $sha.Dispose() }
}
$base = $Root.TrimEnd('\', '/')
$keys = New-Object System.Collections.Generic.List[string]
$vals = New-Object System.Collections.Generic.List[string]
foreach ($f in @(Get-ChildItem -LiteralPath $base -Recurse -File -Force)) {
  $rel = $f.FullName.Substring($base.Length).TrimStart('\', '/').Replace('\', '/')
  $skip = $false
  foreach ($x in $ExcludePrefix) { if ($x -and $rel.StartsWith($x, [StringComparison]::Ordinal)) { $skip = $true } }
  if ($skip) { continue }
  $keys.Add(([BitConverter]::ToString([System.Text.Encoding]::UTF8.GetBytes($rel)) -replace '-', ''))
  $vals.Add($rel + "`t" + $f.Length + "`t" + (Hash-File $f.FullName))
}
$ka = $keys.ToArray(); $va = $vals.ToArray()
[Array]::Sort($ka, $va, [StringComparer]::Ordinal)
$sb = New-Object System.Text.StringBuilder
[void]$sb.Append("상대경로`t크기`tSHA256`n")
foreach ($v in $va) { [void]$sb.Append($v + "`n") }
[System.IO.File]::WriteAllText($Out, $sb.ToString(), (New-Object System.Text.UTF8Encoding($false)))
return (Hash-File $Out)
