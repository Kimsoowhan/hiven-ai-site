#!/usr/bin/env python3
# 컨테이너 러너 1.1(바-2) — 실행 묶음 1.1의 정적 검사 + 같은 절차를 Linux 컨테이너에서 재현(논리 검증, Windows 실제 실행 기록이 아님)
# 쓰는 법: python3 -I runner_container.py <묶음 폴더> <결과 폴더> <시험 묶음 압축본> [SHA256SUMS_0.1.25 파일]
# 종료 코드: 0 = 모든 검사 통과, 1 = 하나라도 실패
import hashlib, os, re, shutil, subprocess, sys, time, platform, datetime, zipfile, tempfile

bundle, out, packzip = sys.argv[1], sys.argv[2], sys.argv[3]
sums = sys.argv[4] if len(sys.argv) > 4 else ''
os.makedirs(out, exist_ok=True)
LOG = os.path.join(out, '실행기록.txt')
fails = []
def now(): return datetime.datetime.now().astimezone().strftime('%Y-%m-%dT%H:%M:%S%z')
def say(m):
    line = f'{now()} {m}'
    print(line)
    with open(LOG, 'a', encoding='utf-8') as f: f.write(line + '\n')
def check(name, ok, detail=''):
    say(f'[{"통과" if ok else "실패"}] {name} {detail}'.rstrip())
    if not ok: fails.append(name)
    return ok
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''): h.update(b)
    return h.hexdigest()
def wtsv(name, rows):
    with open(os.path.join(out, name), 'w', encoding='utf-8-sig', newline='') as f:
        for r in rows: f.write('\t'.join(str(x) for x in r) + '\r\n')

say(f'러너 1.1 시작 · 묶음 {bundle} · Python {platform.python_version()} · {platform.platform()}')

# ================= A. 정적 검사 =================
PS = ['env_record.ps1', 'manifest_hash.ps1', 'p5_check.ps1', 'pack_list.ps1', 'resource_record.ps1', 'run_bundle.ps1']
ps1 = sorted(x for x in os.listdir(bundle) if x.endswith('.ps1'))
check('A-0 스크립트 6건', ps1 == PS, ','.join(ps1))
static = [('파일', '검사', '결과', '내용')]

def strip_comments(src):
    return '\n'.join(l for l in src.split('\n') if not l.lstrip().startswith('#'))

def balance(src):
    st, i, n = [], 0, len(src)
    pairs = {')': '(', '}': '{', ']': '['}
    while i < n:
        c = src[i]
        if src.startswith('<#', i):
            j = src.find('#>', i + 2); i = n if j < 0 else j + 2; continue
        if c == '#':
            j = src.find('\n', i); i = n if j < 0 else j; continue
        if c == "'":
            j = i + 1
            while j < n:
                if src[j] == "'" and (j + 1 < n and src[j + 1] == "'"): j += 2; continue
                if src[j] == "'": break
                j += 1
            i = j + 1; continue
        if c == '"':
            j = i + 1; depth = 0
            while j < n:
                if src[j] == '`': j += 2; continue
                if src.startswith('$(', j): depth += 1; j += 2; continue
                if src[j] == ')' and depth: depth -= 1; j += 1; continue
                if src[j] == '"' and depth == 0: break
                j += 1
            i = j + 1; continue
        if c == '`': i += 2; continue
        if c in '({[': st.append(c)
        elif c in ')}]':
            if not st or st[-1] != pairs[c]: return f'어긋남 위치 {i}'
            st.pop()
        i += 1
    return '균형' if not st else f'닫히지 않음 {len(st)}개'

forbid_word = re.compile(r'(?i)adm' r'in|어드' r'민|관리' r'자')
# 어디에도 있으면 안 되는 명령: 지우기·옮기기·이름 바꾸기·휴지통·재시작·끄기·프로세스 끄기·설정 쓰기·외부 통신·내려받기 표시 지우기
destructive = re.compile(r'(?i)\b(Remove-Item|Move-Item|Rename-Item|Clear-RecycleBin|Restart-Computer|Stop-Computer|Stop-Process|Set-ItemProperty|New-ItemProperty|Remove-ItemProperty|Set-Service|Invoke-WebRequest|Invoke-RestMethod|Set-MpPreference|Unblock-File|Set-ExecutionPolicy|Copy-Item|Expand-Archive)\b|taskkill|\.Kill\(|\[System\.IO\.(File|Directory)\]::(Delete|Move|Replace)|powercfg(\.exe)?\s+[/-](change|set|setactive|setacvalueindex|setdcvalueindex|hibernate)|\breg(\.exe)?\s+(add|delete|import)')
# 대표님 실제 자료 자리를 가리키는 말(묶음 어디에도 없어야 함)
real_paths = re.compile(r'(?i)USERPROFILE|HiBiz|\\Documents\\|MyDocuments|\[Environment\]::GetFolderPath\(.(Personal|MyDocuments|Desktop)')
for f in PS:
    if f not in ps1: continue
    raw = open(os.path.join(bundle, f), 'rb').read()
    bom = raw.startswith(b'\xef\xbb\xbf')
    src = raw.decode('utf-8-sig')
    code = strip_comments(src)
    b = balance(src)
    fw = forbid_word.findall(src)
    de = [m.group(0) for m in destructive.finditer(code)]
    rp = [m.group(0) for m in real_paths.finditer(code)]
    static += [(f, 'UTF-8 BOM(PowerShell 5.1 한글)', '통과' if bom else '실패', ''),
               (f, '괄호 균형', '통과' if b == '균형' else '실패', b),
               (f, '금지 단어 0건', '통과' if not fw else '실패', len(fw)),
               (f, '지우기·옮기기·끄기·설정 쓰기·외부 통신 명령 0건', '통과' if not de else '실패', ','.join(de)),
               (f, '대표님 실제 자료 자리 0건', '통과' if not rp else '실패', ','.join(rp))]
    check(f'A-1 {f} BOM', bom); check(f'A-2 {f} 괄호', b == '균형', b)
    check(f'A-3 {f} 금지 단어 0', not fw); check(f'A-4 {f} 금지 명령 0', not de, ','.join(de))
    check(f'A-5 {f} 실제 자료 자리 0', not rp, ','.join(rp))

rb = open(os.path.join(bundle, 'run_bundle.ps1'), encoding='utf-8-sig').read()
rbc = strip_comments(rb)
# 허용된 쓰기·실행은 run_bundle.ps1 안에서 정해진 수만큼만
allowed = {'Start-Process': 2, 'subst.exe': 2, 'SetAttributes': 1, 'WriteAllBytes': 1, 'ExtractToDirectory': 1}
for k, nexp in allowed.items():
    cnt = rbc.count(k)
    static.append(('run_bundle.ps1', f'허용 동작 {k} = {nexp}회', '통과' if cnt == nexp else '실패', cnt))
    check(f'A-6 run_bundle {k} {nexp}회', cnt == nexp, str(cnt))
for f in PS:
    if f == 'run_bundle.ps1' or f not in ps1: continue
    c = strip_comments(open(os.path.join(bundle, f), encoding='utf-8-sig').read())
    hit = [k for k in allowed if k in c]
    check(f'A-6 {f} 허용 동작 없음', not hit, ','.join(hit))
# 단계 표지 ⓪~⑧ 순서, 종료 코드, 고정 해시
marks = ['# ---- ⓪', '# ---- ①', '# ---- ②', '# ---- ③', '# ---- ④', '# ---- ⑤', '# ---- ⑥', '# ---- ⑦', '# ---- ⑧']
pos = [rb.find(m) for m in marks]
check('A-7 단계 ⓪~⑧ 순서', all(p >= 0 for p in pos) and pos == sorted(pos), str(pos))
for c in [4, 5, 6, 7, 8, 9, 10, 11, 3, 2]:
    ok = re.search(rf'(Halt {c} |exit {c}\b)', rbc) is not None
    check(f'A-8 종료 코드 {c} 쓰임', ok)
consts = {'EXPECT_PACK_ZIP': '1f66c88a57c2109a476d45e337291eb06aeae65ca5ae2a4fbcbaf622fc1712fe',
          'EXPECT_PACK_LIST': '5c6d1c33ccab208da50ce171a638e6ee468ecd156dcbc24f3d59e43912dd4a34',
          'EXPECT_SETUP': 'fe346ab53c4a1a433f32f63b267935040adba7c047de4deaef6ba9e2da3b7059',
          'EXPECT_EXE': 'e6cc237b8eff1275d9ed50ce91bd9280c54b701e2003d98d2fbf3046910a4c6c'}
for k, v in consts.items():
    m = re.search(rf"\${k} = '([0-9a-f]{{64}})'", rb)
    check(f'A-9 {k} 고정값', bool(m) and m.group(1) == v, m.group(1)[:8] if m else '없음')
if sums and os.path.exists(sums):
    sm = dict((l.split()[1], l.split()[0]) for l in open(sums, encoding='utf-8-sig') if l.strip())
    check('A-9 설치 파일 해시 = SHA256SUMS', sm.get('HiCoffer_Setup_0.1.25.exe') == consts['EXPECT_SETUP'])
    check('A-9 HiCoffer.exe 해시 = SHA256SUMS', sm.get('HiCoffer.exe') == consts['EXPECT_EXE'])
# ⓪ 실행 0개 확인 줄과 높은 권한 확인 줄
check('A-10 ⓪ 실행 0개 확인 줄', re.search(r"\$procs = Hc-Procs", rbc) is not None and 'TryOpenExisting(\'Local\\HiCofferAgent\'' in rbc)
check('A-10 ⓪ 높은 권한 확인 줄(S-1-5-32-544)', 'S-1-5-32-544' in rbc)
check('A-11 ⑤ 시험용 환경 변수 두 개', '$env:HICOFFER_TEST_PROFILE = $P' in rbc and '$env:HICOFFER_TEST_SETTINGS = $S' in rbc)
check('A-11 ⑦ 60분마다 다시 읽기', '-RecheckMinutes $RecheckMinutes' in rbc and "p5_check.ps1" in open(os.path.join(bundle, 'resource_record.ps1'), encoding='utf-8-sig').read())
check('A-12 설치는 조용한 설치(/S)', "-ArgumentList '/S'" in rbc)
for f in os.listdir(bundle):
    if f.endswith('.cmd'):
        ok = all(c < 128 for c in open(os.path.join(bundle, f), 'rb').read())
        static.append((f, 'cmd 본문 ASCII(코드 페이지 무관)', '통과' if ok else '실패', '')); check(f'A-13 {f} ASCII', ok)
wtsv('정적검사.tsv', static)

# ================= B. 절차 재현(논리 검증) =================
work = tempfile.mkdtemp(prefix='hct_runner_')  # 컨테이너 임시 자리(심볼릭 링크가 되는 파일 시스템)
T = os.path.join(work, 'HCT_시험가')
steps = [('단계', '재현 내용', '결과')]

# B-0 ② 시험 묶음 압축본 해시 → 풀기 → pack_list 규칙으로 목록 해시(실제 시험 묶음으로)
zh = sha(packzip)
check('B-0 ② 시험 묶음 압축본 해시', zh == consts['EXPECT_PACK_ZIP'], zh[:8])
with zipfile.ZipFile(packzip) as z: z.extractall(T)
PACK = os.path.join(T, 'HCT_시험가_묶음')
def pack_list(root, outp, exclude=()):
    rows = []
    for r, _, files in os.walk(root):
        for fn in files:
            p = os.path.join(r, fn); rel = os.path.relpath(p, root).replace(os.sep, '/')
            if any(rel.startswith(x) for x in exclude): continue
            rows.append((rel.encode('utf-8'), f'{rel}\t{os.path.getsize(p)}\t{sha(p)}'))
    rows.sort(key=lambda x: x[0])
    with open(outp, 'w', encoding='utf-8', newline='') as f:
        f.write('상대경로\t크기\tSHA256\n')
        for _, v in rows: f.write(v + '\n')
    return sha(outp), len(rows)
lh, ln = pack_list(PACK, os.path.join(out, '묶음목록_시작.tsv'))
check('B-0 ② 풀린 묶음 목록 해시 = 5c6d1c33…4a34', lh == consts['EXPECT_PACK_LIST'], f'{lh[:8]} · {ln}개')
steps.append(('②', f'풀기 {ln}개 · 목록 해시', lh))
# pack_list.ps1이 같은 규칙인지(정렬 = UTF-8 바이트 순, LF, 머리줄, BOM 없음)
pl = open(os.path.join(bundle, 'pack_list.ps1'), encoding='utf-8-sig').read()
check('B-0 pack_list.ps1 규칙 일치', all(k in pl for k in ['UTF8.GetBytes($rel)', '[StringComparer]::Ordinal', '"상대경로`t크기`tSHA256`n"', 'UTF8Encoding($false)', ".Replace('\\', '/')"]))

# B-1 ③ subst 재현(심볼릭 링크로 같은 내용이 보이는지)
media = os.path.join(work, 'X_drive'); os.symlink(os.path.join(PACK, 'M'), media)
check('B-1 ③ 시험 매체 붙이기 재현', os.path.isdir(os.path.join(media, '자료')) and len(os.listdir(os.path.join(media, '자료'))) == 300)
steps.append(('③', '붙인 매체의 자료 폴더 300개', '확인'))

# B-2 ④ 설치 파일 해시 판정 재현(틀린 파일은 멈춤 7)
fake = os.path.join(work, 'HiCoffer_Setup_0.1.25.exe'); open(fake, 'wb').write(b'not the setup')
def stage4(path): return 0 if sha(path) == consts['EXPECT_SETUP'] else 7
check('B-2 ④ 해시 다른 설치 파일 → 멈춤 7', stage4(fake) == 7)
def ver_gate(old, allow=False):
    if not old: return 0
    a = tuple(map(int, old.split('.'))); b = (0, 1, 25)
    if a > b: return 7
    if a < b and not allow: return 7
    return 0
vg = [('없음', '', False, 0), ('같은 판', '0.1.25', False, 0), ('옛 판·허락 없음', '0.1.24', False, 7), ('옛 판·허락', '0.1.24', True, 0), ('새 판', '0.1.26', False, 7)]
for name, v, al, exp in vg: check(f'B-2 ④ 설치된 판 {name}', ver_gate(v, al) == exp)
steps.append(('④', '해시 다름·판 비교 사례 6건', '기대값 일치'))

# B-3 ⑤ 시험 설정 파일 → HiCoffer의 FirstRunDone 규칙(Agent.cs:94~97, Ini.cs 읽기 규칙)으로 첫 실행을 건너뛰는지
m = re.search(r'# INI-BEGIN(.*?)# INI-END', rb, re.S)
D = os.path.join(T, 'D'); S = os.path.join(T, 'S')
lines = []
for raw in re.findall(r"^\s*(\(?'.*?'(?:\s*\+.*?)?\)?),?\s*$", m.group(1) if m else '', re.M):
    t = raw.strip().strip(',')
    t = t.replace("('data_root = ' + $D)", f"'data_root = {D}'").replace("('installed_version = ' + $APPVER)", "'installed_version = 0.1.25'")
    t = re.sub(r"\('notice_accepted = ' \+ \(Get-Date.*?\) \+ '(.*?)'\)", lambda mm: "'notice_accepted = 2026-11-12T00:00:00+09:00" + mm.group(1) + "'", t)
    if t.startswith("'") and t.endswith("'"): lines.append(t[1:-1])
os.makedirs(S, exist_ok=True); os.makedirs(D, exist_ok=True)
open(os.path.join(S, 'settings.ini'), 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
def ini_load(p):
    secs, cur = {}, None
    for line in open(p, encoding='utf-8-sig'):
        t = line.rstrip().strip()
        if t.startswith('[') and t.endswith(']'): cur = secs.setdefault(t[1:-1].strip().lower(), {}); continue
        if cur is None or not t or t[0] in ';#' or '=' not in t: continue
        k, v = t.split('=', 1); v = v.strip(); ci = v.find(' ; ')
        if ci >= 0: v = v[:ci].strip()
        cur[k.strip().lower()] = v
    return secs
ini = ini_load(os.path.join(S, 'settings.ini'))
app = ini.get('app', {})
try: nv = int(app.get('notice_version', '0'))
except ValueError: nv = 0
first_run_done = nv >= 2 and bool(app.get('data_root'))
check('B-3 ⑤ 시험 설정 파일 줄 6', len(lines) == 6, str(len(lines)))
check('B-3 ⑤ FirstRunDone 규칙으로 첫 실행 건너뜀', first_run_done, f"notice_version {nv} · data_root {app.get('data_root')}")
check('B-3 ⑤ 데이터 폴더가 묶음 P 밖', not os.path.abspath(app.get('data_root', '')).startswith(os.path.abspath(os.path.join(PACK, 'P'))))
check('B-3 ⑤ 금고 코드 영문·숫자 4자', re.fullmatch(r'[A-Z0-9]{4}', app.get('vault_code', '')) is not None)
steps.append(('⑤', '시험 설정 파일로 첫 실행 건너뜀', f'FirstRunDone {first_run_done}'))

# B-4 ⓪ 판정과 단계 흐름(종료 코드) 재현
def flow(running=0, held=False, high=False, gate=True, mode='Full', zip_ok=True, list_ok=True, subst_ok=True, setup_ok=True, launch_ok=True, taste_events=('시작', '발견', '끝'), full_events=('시작', '발견', '예약 감시', '끝'), boot_same=True, pack_same=True):
    if running or held or high: return 4
    if mode == 'EnvOnly': return 0
    if not gate and mode == 'Full': return 3
    if not (zip_ok and list_ok): return 5
    if not subst_ok: return 6
    if not setup_ok: return 7
    if not launch_ok: return 8
    if any(e in ('사라짐', '없음', '공백', 'PID 바뀜') for e in taste_events): return 9
    stop10 = mode == 'Full' and (any(e in ('사라짐', '없음', '공백', 'PID 바뀜', '다시 나타남') for e in full_events) or not boot_same)
    if stop10: return 10
    if not pack_same: return 11
    return 0
fc = [('정상 본 시험', {}, 0), ('HiCoffer 1개 실행 중', {'running': 1}, 4), ('잠금만 남음', {'held': True}, 4), ('높은 권한', {'high': True}, 4),
      ('환경만', {'mode': 'EnvOnly'}, 0), ('P-5 대기·본 시험', {'gate': False}, 3), ('P-5 대기·맛보기', {'gate': False, 'mode': 'Short'}, 0),
      ('목록 해시 다름', {'list_ok': False}, 5), ('subst 실패', {'subst_ok': False}, 6), ('설치 해시 다름', {'setup_ok': False}, 7), ('띄우기 실패', {'launch_ok': False}, 8),
      ('맛보기 중 사라짐', {'taste_events': ('시작', '발견', '사라짐', '끝')}, 9), ('24시간 중 사라짐', {'full_events': ('시작', '발견', '사라짐', '다시 나타남', '끝')}, 10),
      ('24시간 중 재부팅', {'boot_same': False}, 10), ('기록 공백', {'full_events': ('시작', '발견', '공백', '끝')}, 10), ('묶음 내용 바뀜', {'pack_same': False}, 11)]
fr = [('사례', '기대 종료 코드', '결과', '판정')]
for name, kw, exp in fc:
    r = flow(**kw); fr.append((name, exp, r, '통과' if r == exp else '실패')); check(f'B-4 흐름 {name}', r == exp, f'{r}')
wtsv('단계흐름_사례.tsv', fr)

# B-5 ⑥·⑦ 자원 기록·생존 감시 + 일정 간격마다 P-5 다시 읽기(재현: 2초마다 다시 읽고 두 번째에 재부팅 대기가 생김)
INTERVAL, TICKS, RECHECK = 2, 6, 2
live = [('시각', '사건', 'PID', '설명')]
child = subprocess.Popen([sys.executable, '-I', '-c', 'import time\nwhile True: time.sleep(0.2)'])
live.append((now(), '시작', '', f'감시 시작 · {TICKS}회 · {INTERVAL}초 간격 · {RECHECK}초마다 예약 감시'))
prev = None; checks = 0; t0 = time.time(); next_check = t0 + RECHECK
for k in range(TICKS):
    t = time.time()
    if t >= next_check:
        checks += 1
        pending = checks == 2
        live.append((now(), '예약 감시', '', '주의: 대기 Windows 업데이트 재부팅 필요' if pending else '새 대기·예약 없음'))
        next_check += RECHECK
    alive = child.poll() is None
    if alive:
        if prev is None: live.append((now(), '발견', child.pid, '프로그램 살아 있음'))
        prev = child.pid
    else:
        if prev: live.append((now(), '사라짐', prev, '프로그램이 멈추거나 닫힘'))
        prev = ''
    time.sleep(max(0, INTERVAL - (time.time() - t)))
child.terminate(); child.wait()
live.append((now(), '끝', '', f'감시 끝 · 기록 {TICKS}줄'))
wtsv('생존감시_표본.tsv', live)
evs = [r[1] for r in live[1:]]
check('B-5 ⑦ 예약 감시 사건이 정한 간격마다 남음', evs.count('예약 감시') >= 2, f'{evs.count("예약 감시")}회')
check('B-5 ⑦ 구간 중 새로 생긴 대기를 사건 줄로 남김', any(r[1] == '예약 감시' and '주의' in r[3] for r in live[1:]))
check('B-5 ⑦ 사라짐 없으면 P-9 걸림 없음', flow(full_events=tuple(evs)) == 0, '→'.join(evs))

# B-6 ⑧ 종료 대조: 그대로면 같음, 매체 00_관리는 빼고, 내용이 바뀌면 잡음
os.makedirs(os.path.join(PACK, 'M', '00_관리'), exist_ok=True)
open(os.path.join(PACK, 'M', '00_관리', 'hcdam_events.tsv'), 'w').write('EV1\n')
e1, _ = pack_list(PACK, os.path.join(out, '묶음목록_종료.tsv'), exclude=('M/00_관리/',))
check('B-6 ⑧ 그대로면 시작 = 종료(00_관리 뺌)', e1 == consts['EXPECT_PACK_LIST'], e1[:8])
with open(os.path.join(PACK, 'P', 'Downloads', '정리도구.bat'), 'ab') as f: f.write(b'x')
e2, _ = pack_list(PACK, os.path.join(work, '묶음목록_종료_변경.tsv'), exclude=('M/00_관리/',))
check('B-6 ⑧ 내용 바뀜을 잡음(종료 코드 11 조건)', e2 != consts['EXPECT_PACK_LIST'])
os.unlink(media)
steps.append(('⑧', '종료 대조 그대로·바뀜 두 경우', '기대값 일치'))
wtsv('재현단계.tsv', steps)
shutil.rmtree(work)  # 러너가 만든 컨테이너 임시 표본만 정리(PC 파일 아님)

code = 0 if not fails else 1
say(f'러너 끝 · 실패 {len(fails)}건 · 종료 코드 {code}')
with open(os.path.join(out, '결과해시.txt'), 'w', encoding='utf-8') as f:
    for x in sorted(x for x in os.listdir(out) if x != '결과해시.txt'): f.write(f'{sha(os.path.join(out, x))}  {x}\n')
sys.exit(code)
