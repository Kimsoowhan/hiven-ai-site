﻿# 자원 기록(P-4 ②, PERF) + 프로그램 생존 감시(P-4 ③)
# 정해진 간격(기본 60초)마다 한 줄씩 바로 써서 중간에 끊겨도 앞 기록이 남게 한다. 읽기만 한다.
# 결과: <앞말>자원기록.csv, <앞말>생존감시.tsv (1.1: 앞말 -Prefix로 맛보기·본 구간을 가름, -RecheckMinutes마다 p5_check.ps1로 P-5a·P-5c를 다시 읽어 「예약 감시」 사건을 남김)
param(
  [Parameter(Mandatory=$true)][string]$OutDir,
  [int]$DurationMinutes = 1440,
  [int]$IntervalSeconds = 60,
  [string]$ProcessName = 'HiCoffer',
  [string]$Prefix = '',
  [int]$RecheckMinutes = 0
)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ErrorActionPreference = 'Continue'
$utf8 = New-Object System.Text.UTF8Encoding($true)
$res = Join-Path $OutDir ($Prefix + '자원기록.csv')
$liv = Join-Path $OutDir ($Prefix + '생존감시.tsv')
[System.IO.File]::WriteAllText($res, "시각,경과초,전체CPU%,여유메모리MB,시스템드라이브여유GB,프로그램살아있음,PID,프로그램CPU%,작업집합MB,전용메모리MB,핸들수,스레드수,간격초`r`n", $utf8)
[System.IO.File]::WriteAllText($liv, "시각`t사건`tPID`t설명`r`n", $utf8)
function Live([string]$ev, [string]$procId, [string]$desc) {
  Add-Content -LiteralPath $liv -Value ((Get-Date -Format 'yyyy-MM-ddTHH:mm:ss') + "`t$ev`t$procId`t$desc") -Encoding UTF8
}
$cores = [Environment]::ProcessorCount
$sysDrv = $env:SystemDrive
$start = Get-Date; $end = $start.AddMinutes($DurationMinutes)
$prevPid = $null; $prevCpu = $null; $prevT = $null; $last = $null
Live '시작' '' ("감시 시작 · 대상 " + $ProcessName + " · " + $DurationMinutes + "분 · " + $IntervalSeconds + "초 간격")
$n = 0
$nextCheck = $null; if ($RecheckMinutes -gt 0) { $nextCheck = $start.AddMinutes($RecheckMinutes) }
while ((Get-Date) -lt $end) {
  $now = Get-Date
  if ($nextCheck -and $now -ge $nextCheck) {
    $left = [math]::Max(0, [int]($end - $now).TotalMinutes)
    try {
      $p5 = & (Join-Path $here 'p5_check.ps1') -WindowMinutes ($left + 60)
      if ($p5.Gate) { Live '예약 감시' '' ('새 대기·예약 없음 · ' + $p5.Text) }
      else { Live '예약 감시' '' ('주의: 대기 ' + ($p5.Hard -join ', ') + ' · 구간 안 예약 ' + ($p5.Hits -join ', ') + ' · ' + $p5.Text) }
    } catch { Live '예약 감시' '' ('읽기 실패: ' + $_.Exception.Message) }
    $nextCheck = $nextCheck.AddMinutes($RecheckMinutes)
  }
  $gap = ''
  if ($last) {
    $gap = [math]::Round(($now - $last).TotalSeconds, 1)
    if ($gap -gt ($IntervalSeconds * 3)) { Live '공백' '' ("기록 간격 " + $gap + "초(절전·멈춤 의심)") }
  }
  $last = $now
  $cpu = ''; $mem = ''; $free = ''
  try { $cpu = (Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'").PercentProcessorTime } catch {}
  try { $mem = [math]::Round((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory / 1024, 0) } catch {}
  try { $free = [math]::Round((Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='" + $sysDrv + "'")).FreeSpace / 1GB, 2) } catch {}
  $p = @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue) | Sort-Object StartTime | Select-Object -First 1
  if ($p) {
    $procId = $p.Id
    if ($null -eq $prevPid) { Live '발견' $procId '프로그램 살아 있음' }
    elseif ($prevPid -eq '') { Live '다시 나타남' $procId '사라졌던 프로그램이 다시 실행됨' }
    elseif ($prevPid -ne $procId) { Live 'PID 바뀜' $procId ("앞 PID " + $prevPid) ; $prevCpu = $null }
    $pc = ''
    $c = $p.TotalProcessorTime.TotalSeconds
    if ($null -ne $prevCpu -and $prevT) { $dt = ($now - $prevT).TotalSeconds; if ($dt -gt 0) { $pc = [math]::Round(($c - $prevCpu) / $dt / $cores * 100, 2) } }
    $prevCpu = $c; $prevT = $now
    $row = @($now.ToString('yyyy-MM-ddTHH:mm:ss'), [math]::Round(($now-$start).TotalSeconds), $cpu, $mem, $free, 1, $procId, $pc, [math]::Round($p.WorkingSet64/1MB,1), [math]::Round($p.PrivateMemorySize64/1MB,1), $p.HandleCount, $p.Threads.Count, $gap)
    $prevPid = $procId
  } else {
    if ($null -eq $prevPid) { Live '없음' '' '감시 시작 때 프로그램이 실행 중이 아님' }
    elseif ($prevPid -ne '') { Live '사라짐' $prevPid '프로그램이 멈추거나 닫힘' }
    $prevPid = ''; $prevCpu = $null
    $row = @($now.ToString('yyyy-MM-ddTHH:mm:ss'), [math]::Round(($now-$start).TotalSeconds), $cpu, $mem, $free, 0, '', '', '', '', '', '', $gap)
  }
  Add-Content -LiteralPath $res -Value ($row -join ',') -Encoding UTF8
  $n++
  $wait = $IntervalSeconds - ((Get-Date) - $now).TotalSeconds
  if ($wait -gt 0) { Start-Sleep -Milliseconds ([int]($wait * 1000)) }
}
Live '끝' '' ("감시 끝 · 기록 " + $n + "줄")
return $n
