﻿# 시험 가 실행 묶음 1.1 「한 번 시작」(바-2) — ⓪ 실행 0개 확인 → ① 환경 기록·P-5 판정 → ② 시험 폴더에 묶음 풀기·목록 해시 대조 → ③ subst로 시험 매체 M 붙이기
#   → ④ 설치 파일 해시 대조·조용한 설치 → ⑤ 시험용 환경 변수로 HiCoffer 띄우기 → ⑥ 3분 맛보기 → ⑦ 24시간 자원 기록·생존 감시(60분마다 P-5a·P-5c 다시 읽기)
#   → ⑧ 종료 목록 해시·종료 대조·subst 떼기·결과 해시
# 쓰기는 시험 전용 폴더(-TestRoot) 한 곳과, 설치 파일이 스스로 하는 설치(사용자 권한, %LOCALAPPDATA%\Programs\HiCoffer · HKCU 키 · 바로가기)뿐이다.
# 대표님 실제 자료·HiBiz 폴더는 읽지도 쓰지도 않는다(묶음 자신과 묶음 옆의 시험 묶음 압축본·설치 파일만 읽음). 파일 이동·지우기·이름 바꾸기, 설정 변경, HiCoffer 끄기를 하지 않는다.
# 단계마다 실패하면 그 자리에서 멈추고 사유를 실행기록.txt·단계기록.tsv에 적는다.
# 종료 코드: 0 정상 · 2 묶음 오류 · 3 P-5로 시작하지 않음 · 4 ⓪ 실행 중이거나 높은 권한 · 5 ② 시험 폴더·묶음 해시 · 6 ③ subst · 7 ④ 설치
#            8 ⑤ 띄우기 · 9 ⑥ 맛보기 중 사라짐 · 10 ⑦ P-9 무효 규칙(중단) · 11 ⑧ 시험 묶음 P·M 내용 바뀜(결함 후보)
# 쓰는 법: 시작.cmd (본 시험: ⓪~⑧, 24시간) · 시작.cmd -Mode Short (맛보기: ⓪~⑥ 뒤 ⑧) · 시작.cmd -Mode EnvOnly (⓪·①만)
param(
  [ValidateSet('Full','Short','EnvOnly')][string]$Mode = 'Full',
  [string]$TestRoot = 'C:\HCT_시험가',
  [string]$PackZip = '',
  [string]$SetupPath = '',
  [string]$MediaLetter = '',
  [string]$ProcessName = 'HiCoffer',
  [int]$DurationMinutes = 1440,
  [int]$IntervalSeconds = 60,
  [int]$RecheckMinutes = 60,
  [switch]$AllowUpgrade,
  [switch]$ManualFirstRun
)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$BUNDLE_VER = '1.1'
$APPVER = '0.1.25'
$PACK_ZIP_NAME = 'HCT_시험가_묶음-261112_1.0_작업.zip'
$SETUP_NAME = 'HiCoffer_Setup_0.1.25.exe'
$EXPECT_PACK_ZIP = '1f66c88a57c2109a476d45e337291eb06aeae65ca5ae2a4fbcbaf622fc1712fe'
$EXPECT_PACK_LIST = '5c6d1c33ccab208da50ce171a638e6ee468ecd156dcbc24f3d59e43912dd4a34'
$EXPECT_SETUP = 'fe346ab53c4a1a433f32f63b267935040adba7c047de4deaef6ba9e2da3b7059'
$EXPECT_EXE = 'e6cc237b8eff1275d9ed50ce91bd9280c54b701e2003d98d2fbf3046910a4c6c'
$APPKEY = 'HKCU:\Software\HIVEN\HiCoffer'
if ($Mode -eq 'Short') { $DurationMinutes = 3; $IntervalSeconds = 10; if (-not $PSBoundParameters.ContainsKey('TestRoot')) { $TestRoot = 'C:\HCT_시험가_맛보기' } }
$TestRoot = $TestRoot.TrimEnd('\')

# 시험 전용 폴더: 없거나 결과_* 폴더만 있어야 한다(앞 시험이 남긴 것을 지우지 않고 멈춤)
if (Test-Path -LiteralPath $TestRoot) {
  $other = @(Get-ChildItem -LiteralPath $TestRoot -Force | Where-Object { $_.Name -notlike '결과_*' })
  if ($other.Count -gt 0) { Write-Host ('시험 전용 폴더 ' + $TestRoot + '에 앞 시험의 파일이 있어 멈춥니다(지우지 않음). 다른 -TestRoot를 주십시오. 종료 코드 5'); exit 5 }
}
$OutDir = Join-Path $TestRoot ('결과_' + (Get-Date -Format 'yyMMdd_HHmmss') + '_' + $Mode)
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$log = Join-Path $OutDir '실행기록.txt'
$stageLog = Join-Path $OutDir '단계기록.tsv'
$utf8 = New-Object System.Text.UTF8Encoding($true)
[System.IO.File]::WriteAllText($stageLog, "시각`t단계`t결과`t내용`r`n", $utf8)
function Say([string]$m) { $l = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss') + ' ' + $m; Add-Content -LiteralPath $log -Value $l -Encoding UTF8; Write-Host $l }
function Stage([string]$st, [string]$res, [string]$m) {
  Add-Content -LiteralPath $stageLog -Value ((Get-Date -Format 'yyyy-MM-ddTHH:mm:ss') + "`t$st`t$res`t" + ($m -replace "[`t`r`n]+", ' ')) -Encoding UTF8
  Say ("[" + $st + "] " + $res + " · " + $m)
}
function Halt([int]$code, [string]$st, [string]$why) { Stage $st '멈춤' ($why + ' · 종료 코드 ' + $code); Say ('묶음 멈춤 · 종료 코드 ' + $code); exit $code }
function Hash-File([string]$path) {
  $sha = [System.Security.Cryptography.SHA256]::Create()
  $fs = [System.IO.File]::Open($path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete)
  try { return ([BitConverter]::ToString($sha.ComputeHash($fs)) -replace '-', '').ToLowerInvariant() } finally { $fs.Dispose(); $sha.Dispose() }
}
function Find-Beside([string]$given, [string]$name) {
  if ($given) { if (Test-Path -LiteralPath $given -PathType Leaf) { return $given } else { return $null } }
  foreach ($d in @($here, (Split-Path -Parent $here))) { $p = Join-Path $d $name; if (Test-Path -LiteralPath $p -PathType Leaf) { return $p } }
  return $null
}
function Reg-Val([string]$path, [string]$name) { $p = Get-ItemProperty -LiteralPath $path -ErrorAction SilentlyContinue; if ($null -eq $p) { return $null }; return $p.$name }
function Hc-Procs { return @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue) }

try {
  Say ('묶음 ' + $BUNDLE_VER + ' 시작 · 방식 ' + $Mode + ' · ' + $DurationMinutes + '분 · ' + $IntervalSeconds + '초 간격 · 시험 폴더 ' + $TestRoot + ' · 결과 ' + $OutDir)
  try { $boot = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToString('yyyy-MM-ddTHH:mm:ss') } catch { $boot = '확인 안 됨' }
  Say ('마지막 부팅 시각 ' + $boot + ' (P-9 판독: 이 값이 종료 때와 다르면 구간 안 재부팅)')
  foreach ($f in (Get-ChildItem -LiteralPath $here -File | Where-Object { $_.Extension -in '.ps1','.cmd','.txt' } | Sort-Object Name)) { Say ('묶음 파일 ' + $f.Name + ' ' + (Hash-File $f.FullName)) }

  # ---- ⓪ HiCoffer 실행 0개 확인(있으면 끄지 않고 멈춤) · 높은 권한이 아닌지 ----
  $procs = Hc-Procs
  $held = $false; $mx = $null
  try { $held = [System.Threading.Mutex]::TryOpenExisting('Local\HiCofferAgent', [ref]$mx); if ($mx) { $mx.Dispose() } } catch [System.UnauthorizedAccessException] { $held = $true } catch { }
  if ($procs.Count -gt 0 -or $held) { Halt 4 '⓪' ('HiCoffer 실행 ' + $procs.Count + '개 · 잠금(Local\HiCofferAgent) ' + $held + ' → 끄지 않고 멈춤. 시험용 실행이 앞 창에 붙어 실제 자료 위에서 돌게 됨(Program.cs:16·21)') }
  $sid544 = New-Object System.Security.Principal.SecurityIdentifier('S-1-5-32-544')
  $high = (New-Object System.Security.Principal.WindowsPrincipal([System.Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole($sid544)
  if ($high) { Halt 4 '⓪' '높은 권한(상승 권한)으로 실행됨 → 설치 파일 .onInit과 Program.cs:47~49가 경고 창을 띄움. 시작.cmd를 두 번 눌러 일반 권한으로 실행' }
  Stage '⓪' '통과' 'HiCoffer 실행 0개 · 잠금 없음 · 일반 권한'

  # ---- ① 환경 기록 · P-5 판정 ----
  $gate = & (Join-Path $here 'env_record.ps1') -OutDir $OutDir -DurationMinutes $DurationMinutes -TestRoot $TestRoot
  $gate = [bool]($gate | Select-Object -Last 1)
  Stage '①' $(if ($gate) { '통과' } else { 'P-5 시작하지 않음 조건' }) '환경기록.tsv'
  if ($Mode -eq 'EnvOnly') { Say '환경 기록만 하고 끝'; exit 0 }
  if (-not $gate -and $Mode -eq 'Full') { Halt 3 '①' 'P-5: 다시 시작 대기·구간 안 예약이 있음(환경기록.tsv P-5a·P-5c)' }

  # ---- ② 시험 전용 폴더에 묶음 풀기 · 목록 해시 대조 ----
  $zip = Find-Beside $PackZip $PACK_ZIP_NAME
  if (-not $zip) { Halt 5 '②' ('시험 묶음 압축본 ' + $PACK_ZIP_NAME + '을 묶음 폴더나 그 위 폴더에서 찾지 못함') }
  $zh = Hash-File $zip
  if ($zh -ne $EXPECT_PACK_ZIP) { Halt 5 '②' ('시험 묶음 압축본 해시 다름 ' + $zh) }
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $TestRoot)
  $PACK = Join-Path $TestRoot 'HCT_시험가_묶음'
  $P = Join-Path $PACK 'P'; $M = Join-Path $PACK 'M'
  $hid = Join-Path $P 'Downloads\숨김실행.exe'
  [System.IO.File]::SetAttributes($hid, ([System.IO.File]::GetAttributes($hid) -bor [System.IO.FileAttributes]::Hidden -bor [System.IO.FileAttributes]::System))
  $lh = & (Join-Path $here 'pack_list.ps1') -Root $PACK -Out (Join-Path $OutDir '묶음목록_시작.tsv')
  if ($lh -ne $EXPECT_PACK_LIST) { Halt 5 '②' ('풀린 묶음 목록 해시 다름 ' + $lh) }
  Stage '②' '통과' ('압축본 ' + $zh + ' · 목록 해시 ' + $lh + ' · 숨김실행.exe 숨김·시스템 속성(정답표 2-3 ②)')

  # ---- ③ subst로 시험 매체 M 붙이기 ----
  $used = @([System.IO.DriveInfo]::GetDrives() | ForEach-Object { $_.Name.Substring(0,1).ToUpperInvariant() })
  $L = ''
  if ($MediaLetter) { $L = $MediaLetter.Substring(0,1).ToUpperInvariant(); if ($used -contains $L) { Halt 6 '③' ('글자 ' + $L + ': 이미 쓰는 중') } }
  else { foreach ($c in 'X','W','V','U','T','R','Q','P') { if ($used -notcontains $c) { $L = $c; break } } }
  if (-not $L) { Halt 6 '③' '빈 드라이브 글자 없음' }
  & subst.exe ($L + ':') $M | Out-Null
  if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath ($L + ':\자료'))) { Halt 6 '③' ('subst ' + $L + ': 붙이기 실패(코드 ' + $LASTEXITCODE + ')') }
  [System.IO.File]::WriteAllText((Join-Path $OutDir '매체글자.txt'), ($L + ":`r`n"), $utf8)
  Stage '③' '통과' ('subst ' + $L + ': = ' + $M + ' (사례 결과에는 「subst 매체 기준」)')

  # ---- ④ 설치 파일 해시 대조 → 조용한 설치(/S) ----
  $setup = Find-Beside $SetupPath $SETUP_NAME
  if (-not $setup) { Halt 7 '④' ('설치 파일 ' + $SETUP_NAME + '을 묶음 폴더나 그 위 폴더에서 찾지 못함') }
  $sh = Hash-File $setup
  if ($sh -ne $EXPECT_SETUP) { Halt 7 '④' ('설치 파일 해시 다름 ' + $sh) }
  $zone = $null; try { $zone = Get-Item -LiteralPath $setup -Stream 'Zone.Identifier' -ErrorAction SilentlyContinue } catch { }
  $rel = Reg-Val 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' 'Release'
  if (-not $rel -or [int]$rel -lt 528040) { Halt 7 '④' ('.NET 4.8 미만(Release ' + $rel + ') → 설치 파일이 안내 창을 띄우고 멈춤(HiCoffer.nsi .onInit)') }
  $oldVer = Reg-Val $APPKEY 'Version'; $oldDir = Reg-Val $APPKEY 'InstallDir'
  Say ('설치 전 HKCU 값: 판 ' + $oldVer + ' · 설치 자리 ' + $oldDir + ' · 원본 내려받기 표시(Zone.Identifier) ' + $(if ($zone) { '있음' } else { '없음' }))
  if ($oldVer) {
    $cmp = ([version]$oldVer).CompareTo([version]$APPVER)
    if ($cmp -gt 0) { Halt 7 '④' ('더 새 판 ' + $oldVer + '이 설치되어 있음 → 설치 파일이 되돌릴지 묻는 창을 띄움(손 걸음). 실제 설치를 바꾸지 않으려고 멈춤') }
    if ($cmp -lt 0 -and -not $AllowUpgrade) { Halt 7 '④' ('설치된 판 ' + $oldVer + '을 ' + $APPVER + '로 올리게 됨(실제 설치가 바뀜). 올려도 되면 -AllowUpgrade') }
  }
  $sdir = Join-Path $TestRoot '설치파일'
  New-Item -ItemType Directory -Force -Path $sdir | Out-Null
  $copy = Join-Path $sdir $SETUP_NAME
  [System.IO.File]::WriteAllBytes($copy, [System.IO.File]::ReadAllBytes($setup))
  if ((Hash-File $copy) -ne $EXPECT_SETUP) { Halt 7 '④' '시험 폴더 사본 해시 다름' }
  $ip = Start-Process -FilePath $copy -ArgumentList '/S' -PassThru
  $null = $ip.Handle
  if (-not $ip.WaitForExit(300000)) { Halt 7 '④' '설치 파일이 5분 안에 끝나지 않음(창이 떴을 수 있음 → 손 걸음으로 셈, 끄지 않음)' }
  if ($ip.ExitCode -ne 0) { Halt 7 '④' ('설치 파일 종료 코드 ' + $ip.ExitCode) }
  $inst = Reg-Val $APPKEY 'InstallDir'; if (-not $inst) { $inst = Join-Path $env:LOCALAPPDATA 'Programs\HiCoffer' }
  $exe = Join-Path $inst 'HiCoffer.exe'
  if (-not (Test-Path -LiteralPath $exe)) { Halt 7 '④' ('설치 뒤 ' + $exe + ' 없음') }
  $eh = Hash-File $exe
  if ($eh -ne $EXPECT_EXE) { Halt 7 '④' ('설치된 HiCoffer.exe 해시가 SHA256SUMS와 다름 ' + $eh) }
  Stage '④' '통과' ('설치 파일 ' + $sh + ' (시험 폴더 사본 실행) · 종료 코드 0 · 설치 자리 ' + $inst + ' · HiCoffer.exe ' + $eh + ' · 설치 뒤 HKCU 판 ' + (Reg-Val $APPKEY 'Version'))

  # ---- ⑤ 시험용 프로필·설정 환경 변수로 묶어 HiCoffer 띄우기 ----
  $D = Join-Path $TestRoot 'D'; $S = Join-Path $TestRoot 'S'; $Q = Join-Path $TestRoot 'Q'
  foreach ($d in $D, $S, $Q) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
  if (-not $ManualFirstRun) {
    # 첫 실행 고지·데이터 폴더 지정을 시험 설정 파일로 건너뜀(Agent.cs:94~97 FirstRunDone, Program.cs:54~62, 저장 형식 Agent.cs:112~119). 실제 설정 폴더는 쓰지 않음
    # INI-BEGIN
    $ini = @(
      '[app]',
      ('data_root = ' + $D),
      'vault_code = MZ01',
      'notice_version = 2',
      ('notice_accepted = ' + (Get-Date -Format 'yyyy-MM-ddTHH:mm:sszzz') + ' ; 시험 묶음 1.1이 시험 설정 파일에 기록(사람이 고지 창을 누르지 않음)'),
      ('installed_version = ' + $APPVER)
    )
    # INI-END
    [System.IO.File]::WriteAllLines((Join-Path $S 'settings.ini'), [string[]]$ini, (New-Object System.Text.UTF8Encoding($false)))
  }
  $env:HICOFFER_TEST_PROFILE = $P
  $env:HICOFFER_TEST_SETTINGS = $S
  $app = Start-Process -FilePath $exe -WorkingDirectory $inst -PassThru
  $null = $app.Handle
  $waitSec = 90; if ($ManualFirstRun) { $waitSec = 1800 }
  $ok = $false; $t0 = Get-Date
  while (((Get-Date) - $t0).TotalSeconds -lt $waitSec) {
    Start-Sleep -Seconds 2
    if ($app.HasExited) { Halt 8 '⑤' ('HiCoffer가 바로 끝남 · 종료 코드 ' + $app.ExitCode) }
    $app.Refresh()
    if ($app.MainWindowHandle -ne [IntPtr]::Zero -and (Test-Path -LiteralPath (Join-Path $D '00_관리\hcdam.ini'))) { $ok = $true; break }
  }
  if (-not $ok) { Halt 8 '⑤' ($waitSec.ToString() + '초 안에 주 화면·시험 데이터 폴더 00_관리가 생기지 않음(끄지 않음)') }
  $all = Hc-Procs
  Stage '⑤' '통과' ('PID ' + $app.Id + ' · HiCoffer 프로세스 ' + $all.Count + '개 · 데이터 폴더 ' + $D + ' · 설정 ' + $S + ' · 사용자 폴더 ' + $P + ' · 첫 실행 ' + $(if ($ManualFirstRun) { '사람이 처리' } else { '시험 설정 파일로 건너뜀' }))

  # 시작 목록 해시(시험 폴더의 데이터·설정·묶음과 설치 자리, %TEMP% 두 곳은 이름·크기만)
  $targets = @($D, $S, $Q, $PACK, $inst)
  $meta = @((Join-Path $env:TEMP 'HiCoffer_view')) + @(Get-ChildItem -LiteralPath $env:TEMP -Directory -Filter 'HiCoffer_selftest_*' -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName })
  $h1 = & (Join-Path $here 'manifest_hash.ps1') -OutDir $OutDir -Label '시작' -Targets $targets -MetaTargets $meta
  Say ('시작 목록 해시 ' + $h1)

  # ---- ⑥ 3분 맛보기 ----
  $n6 = & (Join-Path $here 'resource_record.ps1') -OutDir $OutDir -DurationMinutes 3 -IntervalSeconds 10 -ProcessName $ProcessName -Prefix '맛보기_'
  $ev6 = @(Get-Content -LiteralPath (Join-Path $OutDir '맛보기_생존감시.tsv') -Encoding UTF8 | Select-Object -Skip 1 | ForEach-Object { ($_ -split "`t")[1] })
  $bad6 = @($ev6 | Where-Object { $_ -in '사라짐','없음','공백','PID 바뀜' })
  if ($bad6.Count -gt 0) { Halt 9 '⑥' ('맛보기 중 사건 ' + ($bad6 -join ',') + ' (subst ' + $L + ': 은 붙은 채 둠, 떼려면 subst ' + $L + ': /D)') }
  Stage '⑥' '통과' ('맛보기 3분 · ' + ($n6 | Select-Object -Last 1) + '줄 · 사건 ' + ($ev6 -join '→'))

  # ---- ⑦ 24시간 자원 기록 · 생존 감시(60분마다 P-5a·P-5c 다시 읽기) ----
  $p9 = '해당 없음(맛보기 방식)'; $stop10 = $false
  if ($Mode -eq 'Full') {
    $n7 = & (Join-Path $here 'resource_record.ps1') -OutDir $OutDir -DurationMinutes $DurationMinutes -IntervalSeconds $IntervalSeconds -ProcessName $ProcessName -RecheckMinutes $RecheckMinutes
    $ev7 = @(Get-Content -LiteralPath (Join-Path $OutDir '생존감시.tsv') -Encoding UTF8 | Select-Object -Skip 1 | ForEach-Object { ($_ -split "`t")[1] })
    $bad7 = @($ev7 | Where-Object { $_ -in '사라짐','없음','공백','PID 바뀜','다시 나타남' })
    $rc = @($ev7 | Where-Object { $_ -eq '예약 감시' }).Count
    try { $boot2 = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToString('yyyy-MM-ddTHH:mm:ss') } catch { $boot2 = '확인 안 됨' }
    if ($bad7.Count -gt 0 -or ($boot2 -ne $boot)) { $stop10 = $true; $p9 = '중단(통과로 적지 않음) · 사건 ' + ($bad7 -join ',') + ' · 부팅 ' + $boot + ' → ' + $boot2 }
    else { $p9 = '무효 규칙 걸림 없음 · 예약 감시 ' + $rc + '회' }
    Stage '⑦' $(if ($stop10) { '중단' } else { '통과' }) ('24시간 ' + ($n7 | Select-Object -Last 1) + '줄 · P-9 ' + $p9)
  }

  # ---- ⑧ 종료 목록 해시 · 종료 대조 · subst 떼기 · 결과 해시(⑦이 중단이어도 증적을 남기려고 함) ----
  $lh2 = & (Join-Path $here 'pack_list.ps1') -Root $PACK -Out (Join-Path $OutDir '묶음목록_종료.tsv') -ExcludePrefix @('M/00_관리/')
  $packSame = $true
  $s1 = @(Get-Content -LiteralPath (Join-Path $OutDir '묶음목록_시작.tsv') -Encoding UTF8 | Where-Object { $_ -notlike 'M/00_관리/*' })
  $s2 = @(Get-Content -LiteralPath (Join-Path $OutDir '묶음목록_종료.tsv') -Encoding UTF8)
  if (($s1 -join "`n") -ne ($s2 -join "`n")) { $packSame = $false }
  $h2 = & (Join-Path $here 'manifest_hash.ps1') -OutDir $OutDir -Label '종료' -Targets $targets -MetaTargets $meta
  $a = @{}; foreach ($l in (Get-Content -LiteralPath (Join-Path $OutDir '목록해시_시작.tsv') -Encoding UTF8 | Select-Object -Skip 1)) { $c = $l -split "`t"; $a[$c[0] + '|' + $c[1]] = $c[2] + '|' + $c[4] }
  $b = @{}; foreach ($l in (Get-Content -LiteralPath (Join-Path $OutDir '목록해시_종료.tsv') -Encoding UTF8 | Select-Object -Skip 1)) { $c = $l -split "`t"; $b[$c[0] + '|' + $c[1]] = $c[2] + '|' + $c[4] }
  $diff = New-Object System.Collections.Generic.List[string]
  $diff.Add("구분`t대상|상대경로")
  foreach ($k in $a.Keys) { if (-not $b.ContainsKey($k)) { $diff.Add("사라짐`t$k") } elseif ($a[$k] -ne $b[$k]) { $diff.Add("바뀜`t$k") } }
  foreach ($k in $b.Keys) { if (-not $a.ContainsKey($k)) { $diff.Add("새로 생김`t$k") } }
  [System.IO.File]::WriteAllLines((Join-Path $OutDir '종료대조.tsv'), [string[]]$diff, $utf8)
  & subst.exe ($L + ':') /D | Out-Null
  $gone = -not (Test-Path -LiteralPath ($L + ':\'))
  Stage '⑧' $(if ($packSame -and $gone) { '통과' } else { '확인 필요' }) ('묶음 목록(00_관리 뺌) 시작=종료 ' + $packSame + ' · 종료 목록 해시 ' + $h2 + ' · 종료 대조 차이 ' + ($diff.Count - 1) + '건 · subst ' + $L + ': 떼기 ' + $gone + ' · HiCoffer는 끄지 않고 둠')
  $res = Get-ChildItem -LiteralPath $OutDir -File | Where-Object { $_.Name -ne '결과해시.txt' } | Sort-Object Name
  $sumLines = $res | ForEach-Object { (Hash-File $_.FullName) + '  ' + $_.Name }
  [System.IO.File]::WriteAllLines((Join-Path $OutDir '결과해시.txt'), [string[]]$sumLines, $utf8)
  if ($stop10) { Say ('P-9 ' + $p9); Say '묶음 끝 · 종료 코드 10'; exit 10 }
  if (-not $packSame) { Say '시험 묶음 P·M 내용이 바뀜(결함 후보, 묶음목록_시작·종료 비교)'; Say '묶음 끝 · 종료 코드 11'; exit 11 }
  Say '묶음 정상 끝 · 종료 코드 0'
  exit 0
} catch {
  Say ('묶음 오류: ' + $_.Exception.Message + ' · 줄 ' + $_.InvocationInfo.ScriptLineNumber)
  exit 2
}
