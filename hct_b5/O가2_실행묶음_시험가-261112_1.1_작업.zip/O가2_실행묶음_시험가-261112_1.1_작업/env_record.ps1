﻿# 환경 기록 (P-4 ①, P-5, O가3 대조표 3-2절 E-1~E-7) — 1.1: 데이터 폴더·설정 폴더를 시험 전용 폴더(-TestRoot) 기준으로만 본다(대표님 실제 데이터 폴더는 읽지 않음), P-5a·P-5c는 p5_check.ps1로 읽음
# 읽기만 한다. 설정을 바꾸지 않고 파일을 옮기거나 지우지 않는다. 로그인 값·비밀번호는 읽지 않는다.
# 결과: 환경기록.tsv (번호 · 항목 · 값 · 판정)  /  돌려주는 값: P-5 판정(시작 가능 = $true)
param(
  [Parameter(Mandatory=$true)][string]$OutDir,
  [int]$DurationMinutes = 1440,
  [Parameter(Mandatory=$true)][string]$TestRoot
)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ErrorActionPreference = 'Stop'
$script:rows = New-Object System.Collections.Generic.List[string]
$script:gateStop = New-Object System.Collections.Generic.List[string]

function Add-Row([string]$no, [string]$item, [string]$value, [string]$judge) {
  $v = ($value -replace "[`t`r`n]+", ' ').Trim()
  $script:rows.Add("$no`t$item`t$v`t$judge")
}
function Try-Row([string]$no, [string]$item, [scriptblock]$body) {
  try { $r = & $body; Add-Row $no $item $r[0] $r[1] }
  catch { Add-Row $no $item ("확인 안 됨(읽기 실패: " + $_.Exception.Message + ")") '확인 안 됨' }
}
function Reg-Val([string]$path, [string]$name) {
  $p = Get-ItemProperty -LiteralPath $path -ErrorAction SilentlyContinue
  if ($null -eq $p) { return $null }
  return $p.$name
}
# powercfg /q 결과의 마지막 두 0x 값 = AC, DC (출력 언어와 무관)
function Power-Index([string]$sub, [string]$setting) {
  $out = & powercfg.exe /q SCHEME_CURRENT $sub $setting 2>$null
  $hex = @()
  foreach ($l in $out) { if ($l -match ':\s*0x([0-9a-fA-F]+)\s*$') { $hex += [Convert]::ToInt64($Matches[1], 16) } }
  if ($hex.Count -lt 2) { throw "powercfg 값 없음($setting)" }
  return @($hex[$hex.Count-2], $hex[$hex.Count-1])
}
function Sec-Text([long]$s) { if ($s -eq 0) { return '안 함(0)' } return ([string]([math]::Round($s/60,1)) + '분') }

$SUB_SLEEP='238c9fa8-0aad-41ed-83f4-97be242c8f20'; $STANDBY='29f6c1db-86da-48c5-9fdb-f2b67b1f44da'; $HIBER='9d7815a6-7ee4-497e-8888-515a05f02364'
$SUB_VIDEO='7516b95f-f776-4464-8c53-06167f40cc99'; $VIDEOIDLE='3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e'
$SUB_DISK='0012ee47-9041-4b5d-9b77-535fba8b1442'; $DISKIDLE='6738e2c4-e8a5-4a42-b16a-e040e769756e'
$SUB_USB='2a737441-1930-4402-8d77-b2bebba308a3'; $USBSUSP='48e6b7a6-50f5-4782-a5d4-53bb8f07e226'

Add-Row '0' '기록 시각' (Get-Date -Format 'yyyy-MM-ddTHH:mm:sszzz') '-'
Add-Row '0' '컴퓨터·사용자(이름만)' ($env:COMPUTERNAME + ' / ' + $env:USERNAME) '-'

# ---- P-4 ① 기본 항목 ----
Try-Row 'W-1' 'Windows 판·빌드' {
  $os = Get-CimInstance Win32_OperatingSystem
  $cv = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
  $dv = Reg-Val $cv 'DisplayVersion'; $ubr = Reg-Val $cv 'UBR'
  $j = '확인'; if ([int]$os.BuildNumber -lt 22000) { $j = 'Windows 11 아님' }
  ,@(($os.Caption + ' · ' + $dv + ' · 빌드 ' + $os.BuildNumber + '.' + $ubr + ' · ' + $os.OSArchitecture), $j)
}
Try-Row 'W-2' '전원 계획' {
  $o = (& powercfg.exe /getactivescheme) -join ' '
  ,@($o, '확인')
}
Try-Row 'W-3a' '절전 전환(AC/DC)' { $v = Power-Index $SUB_SLEEP $STANDBY; $j='확인'; if ($v[0] -ne 0) { $j='주의: AC 절전 켜짐 → 24시간 중 절전 가능' }; ,@(('AC ' + (Sec-Text $v[0]) + ' / DC ' + (Sec-Text $v[1])), $j) }
Try-Row 'W-3b' '최대 절전(AC/DC)' { $v = Power-Index $SUB_SLEEP $HIBER; $j='확인'; if ($v[0] -ne 0) { $j='주의: AC 최대 절전 켜짐' }; ,@(('AC ' + (Sec-Text $v[0]) + ' / DC ' + (Sec-Text $v[1])), $j) }
Try-Row 'W-3c' '화면 꺼짐(AC/DC)' { $v = Power-Index $SUB_VIDEO $VIDEOIDLE; ,@(('AC ' + (Sec-Text $v[0]) + ' / DC ' + (Sec-Text $v[1])), '확인(화면 꺼짐은 시험을 끊지 않음)') }
Try-Row 'W-4' '전원 연결' {
  Add-Type -AssemblyName System.Windows.Forms
  $ps = [System.Windows.Forms.SystemInformation]::PowerStatus
  $b = @(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)
  $line = [string]$ps.PowerLineStatus
  $j = '확인'; if ($line -ne 'Online') { $j = '주의: 전원 선 연결 아님' }
  ,@(('전원 선 ' + $line + ' · 배터리 ' + $b.Count + '개 · 충전량 ' + [math]::Round($ps.BatteryLifePercent*100) + '%'), $j)
}
Try-Row 'W-5' '디스크 여유' {
  $d = Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3'
  $t = ($d | ForEach-Object { $_.DeviceID + ' ' + [math]::Round($_.FreeSpace/1GB,1) + '/' + [math]::Round($_.Size/1GB,1) + 'GB' }) -join ' · '
  $low = @($d | Where-Object { $_.Size -gt 0 -and ($_.FreeSpace / $_.Size) -lt 0.1 })
  $j='확인'; if ($low.Count -gt 0) { $j = '주의: 여유 10% 미만 드라이브 있음' }
  ,@($t, $j)
}
Try-Row 'W-6a' '보안 프로그램' {
  $av = @(Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct -ErrorAction SilentlyContinue)
  $t = ($av | ForEach-Object { $_.displayName + '(상태 0x' + ('{0:X6}' -f [int]$_.productState) + ')' }) -join ' · '
  try { $mp = Get-MpComputerStatus; $t += ' · Defender 실시간 보호 ' + $mp.RealTimeProtectionEnabled } catch { $t += ' · Defender 상태 확인 안 됨' }
  ,@($t, '확인')
}
Try-Row 'W-6b' 'SmartScreen(서명 안 된 설치 파일 차단 여부)' {
  $a = Reg-Val 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' 'SmartScreenEnabled'
  $p = Reg-Val 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' 'EnableSmartScreen'
  ,@(('탐색기 설정 ' + $a + ' · 정책 ' + $p), '확인(설치 파일 서명 0건 → 경고 창이 뜰 수 있음)')
}

# ---- P-5 다시 시작 예약 점검(p5_check.ps1, 구간 중 다시 읽기와 같은 규칙) ----
$p5 = & (Join-Path $here 'p5_check.ps1') -WindowMinutes ($DurationMinutes + 60)
if ($p5.Hard.Count -gt 0) { $script:gateStop.Add('재부팅 대기: ' + ($p5.Hard -join ', ')) }
$pj = '시작 가능'; if ($p5.Hard.Count -gt 0) { $pj = '시작하지 않음' }
$pv = '없음'; if ($p5.Pending.Count -gt 0) { $pv = $p5.Pending -join ' · ' }
Add-Row 'P-5a' '다시 시작 대기 상태' $pv $pj
Try-Row 'P-5b' '사용 시간(활성 시간)' {
  $k = 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings'
  $s = Reg-Val $k 'ActiveHoursStart'; $e = Reg-Val $k 'ActiveHoursEnd'; $sm = Reg-Val $k 'SmartActiveHoursState'
  ,@(('시작 ' + $s + '시 · 끝 ' + $e + '시 · 자동 조정 ' + $sm), '확인(24시간 시험은 사용 시간 밖을 반드시 지남 → 아래 P-5c·P-5d로 판정)')
}
if ($p5.Hits.Count -gt 0) { $script:gateStop.Add('시험 구간 안 다시 시작 예약: ' + ($p5.Hits -join ', ')) }
$cj = '시작 가능'; if ($p5.Hits.Count -gt 0) { $cj = '시작하지 않음' }
Add-Row 'P-5c' '업데이트 다시 시작 예약 작업' $p5.Text $cj
Try-Row 'P-5d' '업데이트 일시 중지 만료' {
  $k = 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings'
  $x = Reg-Val $k 'PauseUpdatesExpiryTime'
  $j = '참고(일시 중지 없음: 시험 중 내려받기·설치 가능)'
  if ($x) { try { if ([datetime]$x -gt (Get-Date).AddMinutes($DurationMinutes)) { $j = '확인(시험 구간 동안 일시 중지)' } else { $j = '주의: 시험 구간 안에 일시 중지가 끝남' } } catch {} }
  $v = '설정 없음'; if ($x) { $v = [string]$x }
  ,@($v, $j)
}

# ---- E-1 ~ E-7 (O가3 대조표 3-2절) ----
Try-Row 'E-1' '.NET Framework 판(릴리스 값)' {
  $r = Reg-Val 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' 'Release'
  $j = '확인(4.8 이상)'; if (-not $r -or [int]$r -lt 528040) { $j = '주의: 4.8 미만 또는 없음' }
  ,@(('Release ' + $r), $j)
}
Try-Row 'E-2a' '자동 로그인 사용 여부' {
  $p = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
  $flag = ($p.PSObject.Properties | Where-Object { $_.Name -match '^Auto.*Logon$' } | Select-Object -First 1).Value
  $v = '꺼짐'; if ([string]$flag -eq '1') { $v = '켜짐' }
  ,@(($v + '(값만 기록, 로그인 값은 읽지 않음)'), '확인(재부팅되면 감시가 끊김. 프로그램에 자동 시작 없음)')
}
Try-Row 'E-2b' 'HiCoffer 자동 시작 등록' {
  $hits = @()
  foreach ($k in 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\Run') {
    $p = Get-ItemProperty -LiteralPath $k -ErrorAction SilentlyContinue
    if ($p) { foreach ($q in $p.PSObject.Properties) { if ([string]$q.Value -match 'HiCoffer') { $hits += $q.Name } } }
  }
  $st = [Environment]::GetFolderPath('Startup')
  if (Test-Path -LiteralPath $st) { $hits += @(Get-ChildItem -LiteralPath $st -Filter '*HiCoffer*' -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }) }
  $v = '없음'; if ($hits.Count -gt 0) { $v = $hits -join ', ' }
  ,@($v, '확인')
}
Try-Row 'E-3a' 'USB 선택적 절전(AC/DC)' { $v = Power-Index $SUB_USB $USBSUSP; $m = @{0='사용 안 함';1='사용'}; $j='확인'; if ($v[0] -eq 1) { $j='주의: AC에서 USB 선택적 절전 켜짐(장치 감시 1.5~2초 주기)' }; ,@(('AC ' + $m[[int]$v[0]] + ' / DC ' + $m[[int]$v[1]]), $j) }
Try-Row 'E-3b' '디스크 끄기 시간(AC/DC)' { $v = Power-Index $SUB_DISK $DISKIDLE; ,@(('AC ' + (Sec-Text $v[0]) + ' / DC ' + (Sec-Text $v[1])), '확인') }
$script:dataRoot = $null
Try-Row 'E-4a' '데이터 폴더 실제 경로' {
  $ini = Join-Path (Join-Path $TestRoot 'S') 'settings.ini'
  if (-not (Test-Path -LiteralPath $ini)) { ,@(('시험 설정 파일 아직 없음(' + $ini + ') · ⑤에서 시험 데이터 폴더 ' + (Join-Path $TestRoot 'D') + '로 기록'), '확인(시작 전, 대표님 실제 데이터 폴더는 읽지 않음)'); return }
  $line = Get-Content -LiteralPath $ini -Encoding UTF8 | Where-Object { $_ -match '^\s*data_root\s*=' } | Select-Object -First 1
  $script:dataRoot = ($line -replace '^\s*data_root\s*=\s*', '').Trim()
  ,@($script:dataRoot, '확인')
}
Try-Row 'E-4b' '데이터 폴더가 클라우드 동기화 아래인지' {
  $dr = $script:dataRoot; if (-not $dr) { $dr = Join-Path $TestRoot 'D' }
  $cloud = $false; foreach ($k in 'OneDrive','Dropbox','Google Drive','GoogleDrive','iCloudDrive','iCloud Drive') { if ($dr.IndexOf($k, [StringComparison]::OrdinalIgnoreCase) -ge 0) { $cloud = $true } }
  $usf = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders'
  $doc = [Environment]::ExpandEnvironmentVariables([string](Reg-Val $usf 'Personal'))
  $desk = [Environment]::ExpandEnvironmentVariables([string](Reg-Val $usf 'Desktop'))
  $kfm = ($doc -match 'OneDrive') -or ($desk -match 'OneDrive')
  $j = '확인'; if ($cloud) { $j = '주의: 데이터 폴더가 동기화 폴더 아래' }
  ,@(('데이터 폴더 동기화 ' + $cloud + ' · 문서 폴더 백업(OneDrive) ' + $kfm + ' · 문서=' + $doc), $j)
}
Try-Row 'E-5' '긴 경로 사용(LongPathsEnabled)' {
  $v = Reg-Val 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' 'LongPathsEnabled'
  $j='확인'; if ([string]$v -ne '1') { $j = '참고: 꺼짐 → 260자 넘는 경로는 앱 선언(app.manifest)만으로 처리' }
  ,@(('값 ' + $v), $j)
}
Try-Row 'E-6' '화면 배율·해상도·모니터 수' {
  Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing
  $sc = [System.Windows.Forms.Screen]::AllScreens
  $g = [System.Drawing.Graphics]::FromHwnd([IntPtr]::Zero); $dpi = $g.DpiX; $g.Dispose()
  $ap = Reg-Val 'HKCU:\Control Panel\Desktop\WindowMetrics' 'AppliedDPI'
  $t = ($sc | ForEach-Object { $_.DeviceName + ' ' + $_.Bounds.Width + 'x' + $_.Bounds.Height + $(if ($_.Primary) { '(주)' } else { '' }) }) -join ' · '
  ,@(('모니터 ' + $sc.Count + '대 · ' + $t + ' · DPI ' + $dpi + ' · 적용 DPI ' + $ap + '(' + [math]::Round([double]$ap/96*100) + '%)'), '확인(앱은 단일 배율 선언)')
}
Try-Row 'E-7' '목록 해시 대상 기록 파일·임시 폴더' {
  $dr = Join-Path $TestRoot 'D'
  $list = @((Join-Path $dr '00_관리\hcdam_events.tsv'), (Join-Path $dr '00_관리\logs\storage_diag_timeline.txt'), (Join-Path $dr '00_관리\logs\storage_diag_timeline.txt.1'), (Join-Path $TestRoot 'HCT_시험가_묶음\M\00_관리\hcdam_events.tsv'), (Join-Path $env:TEMP 'HiCoffer_view'))
  $list += @(Get-ChildItem -LiteralPath $env:TEMP -Directory -Filter 'HiCoffer_selftest_*' -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName })
  $t = ($list | ForEach-Object { $_ + '=' + $(if (Test-Path -LiteralPath $_) { '있음' } else { '없음' }) }) -join ' · '
  $list | Set-Content -LiteralPath (Join-Path $OutDir '목록해시_대상_E7.txt') -Encoding UTF8
  ,@($t, '확인(시험 폴더 안 기록은 내용 해시, %TEMP% 두 곳은 이름·크기만)')
}

$gate = ($script:gateStop.Count -eq 0)
$gv = '시작 가능'; if (-not $gate) { $gv = '시작하지 않음: ' + ($script:gateStop -join ' / ') }
Add-Row 'P-5' 'P-5 종합 판정' $gv $(if ($gate) { '시작 가능' } else { '시작하지 않음' })
$hdr = "번호`t항목`t값`t판정"
$utf8 = New-Object System.Text.UTF8Encoding($true)
[System.IO.File]::WriteAllLines((Join-Path $OutDir '환경기록.tsv'), [string[]](@($hdr) + $script:rows), $utf8)
return $gate
