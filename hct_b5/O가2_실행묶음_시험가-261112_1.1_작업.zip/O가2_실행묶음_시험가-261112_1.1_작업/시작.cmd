@echo off
rem HiCoffer test-ga run bundle 1.1 (one start). Usage: start.cmd  |  start.cmd -Mode Short  |  start.cmd -Mode EnvOnly  |  start.cmd -TestRoot "D:\HCT_test"
rem Double-click as a normal user (not elevated). Exit codes are listed in run_bundle.ps1 header.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_bundle.ps1" %*
echo exit code %ERRORLEVEL%
exit /b %ERRORLEVEL%
