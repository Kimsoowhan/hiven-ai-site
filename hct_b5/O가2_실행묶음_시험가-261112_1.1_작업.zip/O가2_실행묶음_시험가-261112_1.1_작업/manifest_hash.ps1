﻿# 시작·종료 목록 해시(P-4 ④) — 대상 경로의 파일 목록과 SHA-256을 남기고, 목록 파일 자체의 해시도 남긴다
# 프로그램이 열어 둔 기록 파일도 읽을 수 있게 공유 읽기로 연다. 읽기만 한다.
# 1.1: -MetaTargets(%TEMP%의 HiCoffer_view·HiCoffer_selftest_*)는 내용을 읽지 않고 이름·크기·수정 시각만 남긴다(금고 보기 임시 파일을 읽지 않기 위함)
param(
  [Parameter(Mandatory=$true)][string]$OutDir,
  [Parameter(Mandatory=$true)][string]$Label,
  [Parameter(Mandatory=$true)][string[]]$Targets,
  [string[]]$MetaTargets = @()
)
$ErrorActionPreference = 'Continue'
function Hash-File([string]$path) {
  $sha = [System.Security.Cryptography.SHA256]::Create()
  $fs = [System.IO.File]::Open($path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete)
  try { return ([BitConverter]::ToString($sha.ComputeHash($fs)) -replace '-', '').ToLowerInvariant() } finally { $fs.Dispose(); $sha.Dispose() }
}
$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("대상`t상대경로`t크기`t수정시각`tSHA256")
foreach ($t in $Targets) {
  if (-not $t) { continue }
  if (Test-Path -LiteralPath $t -PathType Leaf) { $files = @(Get-Item -LiteralPath $t); $base = Split-Path -Parent $t }
  elseif (Test-Path -LiteralPath $t -PathType Container) { $files = @(Get-ChildItem -LiteralPath $t -Recurse -File -Force -ErrorAction SilentlyContinue); $base = $t }
  else { $lines.Add("$t`t(없음)`t`t`t"); continue }
  foreach ($f in ($files | Sort-Object FullName)) {
    $rel = $f.FullName.Substring($base.TrimEnd('\','/').Length).TrimStart('\','/')
    $h = ''; try { $h = Hash-File $f.FullName } catch { $h = '읽기 실패: ' + $_.Exception.Message }
    $lines.Add("$t`t$rel`t$($f.Length)`t$($f.LastWriteTime.ToString('yyyy-MM-ddTHH:mm:ss'))`t$h")
  }
}
foreach ($t in $MetaTargets) {
  if (-not $t) { continue }
  if (-not (Test-Path -LiteralPath $t -PathType Container)) { $lines.Add("$t`t(없음)`t`t`t"); continue }
  foreach ($f in (@(Get-ChildItem -LiteralPath $t -Recurse -File -Force -ErrorAction SilentlyContinue) | Sort-Object FullName)) {
    $rel = $f.FullName.Substring($t.TrimEnd('\','/').Length).TrimStart('\','/')
    $lines.Add("$t`t$rel`t$($f.Length)`t$($f.LastWriteTime.ToString('yyyy-MM-ddTHH:mm:ss'))`t읽지 않음(이름·크기만)")
  }
}
$utf8 = New-Object System.Text.UTF8Encoding($true)
$out = Join-Path $OutDir ("목록해시_" + $Label + ".tsv")
[System.IO.File]::WriteAllLines($out, [string[]]$lines, $utf8)
$mh = Hash-File $out
[System.IO.File]::WriteAllText(($out + '.sha256'), ($mh + '  ' + (Split-Path -Leaf $out) + "`r`n"), $utf8)
return $mh
