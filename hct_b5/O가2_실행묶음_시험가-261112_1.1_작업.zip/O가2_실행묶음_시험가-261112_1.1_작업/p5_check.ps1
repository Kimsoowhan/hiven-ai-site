﻿# 다시 시작 대기·예약 점검(P-5a · P-5c) — 시작 때(env_record.ps1)와 24시간 구간 중 60분마다(resource_record.ps1) 같은 규칙으로 읽는다
# 읽기만 한다. 설정을 바꾸지 않는다.
# 돌려주는 값: 해시표 { Gate = 시작 가능 여부, Pending = 대기 목록, Hard = 시작을 막는 대기, Hits = 구간 안 예약 작업, Text = 예약 작업 설명 }
param(
  [int]$WindowMinutes = 1500
)
$ErrorActionPreference = 'Continue'
$pending = @()
if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') { $pending += 'Windows 업데이트 재부팅 필요' }
if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') { $pending += '구성 요소 서비스 재부팅 대기' }
try {
  $sm = Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -ErrorAction SilentlyContinue
  if ($sm -and $sm.PendingFileRenameOperations) { $pending += '파일 교체 대기(참고)' }
} catch {}
$hard = @($pending | Where-Object { $_ -ne '파일 교체 대기(참고)' })
$limit = (Get-Date).AddMinutes($WindowMinutes)
$hits = @(); $txt = @()
try {
  $tasks = @(Get-ScheduledTask -TaskPath '\Microsoft\Windows\UpdateOrchestrator\' -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -match 'Reboot' -and $_.State -ne 'Disabled' })
  foreach ($t in $tasks) {
    $i = Get-ScheduledTaskInfo -InputObject $t
    $n = $i.NextRunTime
    $txt += ($t.TaskName + ' 다음 ' + $(if ($n) { $n.ToString('yyyy-MM-dd HH:mm') } else { '없음' }))
    if ($n -and $n -gt (Get-Date).AddYears(-1) -and $n -lt $limit) { $hits += $t.TaskName }
  }
} catch { $txt += ('예약 작업 읽기 실패: ' + $_.Exception.Message) }
$t2 = '예약 작업 없음'; if ($txt.Count -gt 0) { $t2 = $txt -join ' · ' }
return @{ Gate = (($hard.Count -eq 0) -and ($hits.Count -eq 0)); Pending = $pending; Hard = $hard; Hits = $hits; Text = $t2 }
